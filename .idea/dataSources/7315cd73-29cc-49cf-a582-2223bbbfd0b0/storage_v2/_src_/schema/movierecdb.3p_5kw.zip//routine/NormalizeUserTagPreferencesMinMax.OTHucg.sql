create
    definer = root@localhost procedure NormalizeUserTagPreferencesMinMax()
BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE current_user_id INT;
    DECLARE current_tag_id INT;
    DECLARE current_score DOUBLE;
    DECLARE user_score_min DOUBLE;
    DECLARE user_score_max DOUBLE;
    DECLARE score_range DOUBLE;

    -- 定义游标，用于遍历 movie_usertagprefer 表中的每条记录
    DECLARE cur CURSOR FOR
        SELECT user_id, tag_id, score
        FROM movie_usertagprefer;

    -- 定义异常处理，当游标遍历完所有记录时，将 done 设为 1
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    OPEN cur;

    read_loop: LOOP
        -- 从游标中获取当前记录的信息
        FETCH cur INTO current_user_id, current_tag_id, current_score;
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- 计算当前用户偏好度的最小值
        SELECT MIN(score) INTO user_score_min
        FROM movie_usertagprefer
        WHERE user_id = current_user_id;

        -- 计算当前用户偏好度的最大值
        SELECT MAX(score) INTO user_score_max
        FROM movie_usertagprefer
        WHERE user_id = current_user_id;

        -- 计算最大最小值的差值
        SET score_range = user_score_max - user_score_min;

        -- 处理最大最小值相同的情况，避免除零错误
        IF score_range = 0 THEN
            SET score_range = 1;
        END IF;

        -- 使用最大最小归一化公式更新当前记录的分数
        UPDATE movie_usertagprefer
        SET score = (current_score - user_score_min) / score_range
        WHERE user_id = current_user_id AND tag_id = current_tag_id;

    END LOOP;

    CLOSE cur;

END;

