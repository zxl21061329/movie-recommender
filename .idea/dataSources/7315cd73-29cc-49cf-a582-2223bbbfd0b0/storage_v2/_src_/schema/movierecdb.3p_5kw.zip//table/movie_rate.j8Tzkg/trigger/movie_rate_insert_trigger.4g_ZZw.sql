create definer = root@localhost trigger movie_rate_insert_trigger
    after insert
    on movie_rate
    for each row
BEGIN
    DECLARE tag_count INT;
    DECLARE tag_id INT;
    DECLARE preference_increase DECIMAL(5, 1);
    DECLARE tag_cursor CURSOR FOR
    SELECT tags_id
    FROM movie_movie_tags
    WHERE movie_id = NEW.movie_id;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET @done = 1;

    -- 获取电影的标签数量
    SELECT COUNT(*) INTO tag_count
    FROM movie_movie_tags
    WHERE movie_id = NEW.movie_id;

    -- 计算每个标签的偏好度增加量
    SET preference_increase = NEW.mark / tag_count;

    OPEN tag_cursor;
    SET @done = 0;
    read_loop: LOOP
        FETCH tag_cursor INTO tag_id;
        IF @done THEN
            LEAVE read_loop;
        END IF;

        -- 更新或插入用户与标签的偏好度
        INSERT INTO movie_usertagprefer (user_id, tag_id, score)
        VALUES (NEW.user_id, tag_id, preference_increase)
        ON DUPLICATE KEY UPDATE
        score = score + preference_increase;
    END LOOP;
    CLOSE tag_cursor;
END;

