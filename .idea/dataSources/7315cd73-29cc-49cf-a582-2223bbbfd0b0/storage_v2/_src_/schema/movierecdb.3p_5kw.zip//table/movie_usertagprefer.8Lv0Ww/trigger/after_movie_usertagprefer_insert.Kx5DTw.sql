create definer = root@localhost trigger after_movie_usertagprefer_insert
    after insert
    on movie_usertagprefer
    for each row
BEGIN
    -- 重新计算当前用户的均值和标准差
    SET @mean = (SELECT AVG(score) FROM movie_usertagprefer WHERE user_id = NEW.user_id);
    SET @std_dev = (SELECT STDDEV(score) FROM movie_usertagprefer WHERE user_id = NEW.user_id);
    -- 插入或更新归一化后的数据
    INSERT INTO movie_usertagpreferencedegree (preference_score, last_updated, tag_id, user_id)
    VALUES ((NEW.score - @mean) / @std_dev, NOW(6), NEW.tag_id, NEW.user_id)
    ON DUPLICATE KEY UPDATE
        preference_score = (NEW.score - @mean) / @std_dev,
        last_updated = NOW(6);
END;

