create
    definer = root@localhost procedure NormalizeUserTagPreferences()
BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE current_user_id INT;
    DECLARE current_tag_id INT;
    DECLARE current_score DOUBLE;
    DECLARE total_score_for_user DOUBLE;
    DECLARE cur CURSOR FOR
        SELECT user_id, tag_id, score
        FROM movie_usertagprefer;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    -- 若临时表 user_total_scores 存在，就将其删除
    DROP TEMPORARY TABLE IF EXISTS user_total_scores;

    -- 第一步：为每个用户计算偏好度总和
    CREATE TEMPORARY TABLE user_total_scores AS
    SELECT
        user_id,
        SUM(score) AS total_score
    FROM
        movie_usertagprefer
    GROUP BY
        user_id;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO current_user_id, current_tag_id, current_score;
        IF done THEN
            LEAVE read_loop;
        END IF;

        SELECT total_score INTO total_score_for_user
        FROM user_total_scores
        WHERE user_id = current_user_id;

        UPDATE movie_usertagprefer
        SET score = CASE
            WHEN total_score_for_user = 0 THEN 0
            ELSE current_score / total_score_for_user
        END
        WHERE user_id = current_user_id AND tag_id = current_tag_id;

    END LOOP;

    CLOSE cur;

    -- 第三步：删除临时表
    DROP TEMPORARY TABLE user_total_scores;
END;

