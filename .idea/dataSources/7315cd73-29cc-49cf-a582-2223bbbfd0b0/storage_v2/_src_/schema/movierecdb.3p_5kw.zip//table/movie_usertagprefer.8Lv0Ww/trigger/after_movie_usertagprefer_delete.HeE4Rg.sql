create definer = root@localhost trigger after_movie_usertagprefer_delete
    after delete
    on movie_usertagprefer
    for each row
BEGIN
    -- 重新计算当前用户的均值和标准差
    SET @mean = (SELECT AVG(score) FROM movie_usertagprefer WHERE user_id = OLD.user_id);
    SET @std_dev = (SELECT STDDEV(score) FROM movie_usertagprefer WHERE user_id = OLD.user_id);
    -- 删除对应的归一化数据
    DELETE FROM movie_usertagpreferencedegree
    WHERE tag_id = OLD.tag_id AND user_id = OLD.user_id;
    -- 重新插入所有归一化数据（因为均值和标准差已改变）
    INSERT INTO movie_usertagpreferencedegree (preference_score, last_updated, tag_id, user_id)
    SELECT
        (score - @mean) / @std_dev AS preference_score,
        NOW(6) AS last_updated,
        tag_id,
        user_id
    FROM
        movie_usertagprefer
    WHERE user_id = OLD.user_id
    ON DUPLICATE KEY UPDATE
        preference_score = VALUES(preference_score),
        last_updated = VALUES(last_updated);
END;

