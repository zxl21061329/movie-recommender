create
    definer = root@localhost procedure NormalizeUserTagPreferencesZScore()
BEGIN
    -- 声明循环结束标志
    DECLARE done INT DEFAULT 0;
    -- 声明当前用户 ID
    DECLARE current_user_id INT;
    -- 声明当前标签 ID
    DECLARE current_tag_id INT;
    -- 声明当前用户对当前标签的偏好度分数
    DECLARE current_score DOUBLE;
    -- 声明当前用户偏好度分数的均值
    DECLARE user_score_mean DOUBLE;
    -- 声明当前用户偏好度分数的标准差
    DECLARE user_score_stddev DOUBLE;

    -- 定义游标，用于遍历 movie_usertagprefer 表中的每一行记录
    DECLARE cur CURSOR FOR
        SELECT user_id, tag_id, score
        FROM movie_usertagprefer;

    -- 定义异常处理，当游标遍历到表末尾，没有更多记录时，将 done 标志设置为 1
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    -- 打开游标
    OPEN cur;

    -- 定义循环标签
    read_loop: LOOP
        -- 从游标中获取当前记录的用户 ID、标签 ID 和偏好度分数
        FETCH cur INTO current_user_id, current_tag_id, current_score;
        -- 判断是否遍历到表末尾，如果是则退出循环
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- 计算当前用户偏好度分数的均值
        SELECT AVG(score) INTO user_score_mean
        FROM movie_usertagprefer
        WHERE user_id = current_user_id;

        -- 计算当前用户偏好度分数的标准差
        SELECT STDDEV(score) INTO user_score_stddev
        FROM movie_usertagprefer
        WHERE user_id = current_user_id;

        -- 处理标准差为 0 的情况，避免除零错误，将标准差设为 1
        IF user_score_stddev = 0 THEN
            SET user_score_stddev = 1;
        END IF;

        -- 使用 Z - Score 归一化公式更新当前记录的偏好度分数
        UPDATE movie_usertagprefer
        SET score = (current_score - user_score_mean) / user_score_stddev
        WHERE user_id = current_user_id AND tag_id = current_tag_id;

    END LOOP;

    -- 关闭游标
    CLOSE cur;

END;

