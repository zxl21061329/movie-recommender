create definer = root@localhost trigger movie_rate_delete_trigger
    after delete
    on movie_rate
    for each row
BEGIN
    DECLARE tag_count INT;
    DECLARE tag_id INT;
    DECLARE preference_decrease DECIMAL(5, 1);
    DECLARE tag_cursor CURSOR FOR
    SELECT tags_id
    FROM movie_movie_tags
    WHERE movie_id = OLD.movie_id;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET @done = 1;

    -- 获取电影的标签数量
    SELECT COUNT(*) INTO tag_count
    FROM movie_movie_tags
    WHERE movie_id = OLD.movie_id;

    -- 计算每个标签的偏好度减少量
    SET preference_decrease = OLD.mark / tag_count;

    OPEN tag_cursor;
    SET @done = 0;
    read_loop: LOOP
        FETCH tag_cursor INTO tag_id;
        IF @done THEN
            LEAVE read_loop;
        END IF;

        -- 更新用户与标签的偏好度
        UPDATE movie_usertagprefer
        SET score = score - preference_decrease
        WHERE user_id = OLD.user_id AND tag_id = tag_id;
    END LOOP;
    CLOSE tag_cursor;
END;

