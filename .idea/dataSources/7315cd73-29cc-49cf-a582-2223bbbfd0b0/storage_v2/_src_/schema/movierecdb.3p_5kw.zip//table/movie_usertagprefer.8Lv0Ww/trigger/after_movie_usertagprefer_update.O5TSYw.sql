create definer = root@localhost trigger after_movie_usertagprefer_update
    after update
    on movie_usertagprefer
    for each row
BEGIN
    -- 重新计算当前用户的均值和标准差
    SET @mean = (SELECT AVG(score) FROM movie_usertagprefer WHERE user_id = NEW.user_id);
    SET @std_dev = (SELECT STDDEV(score) FROM movie_usertagprefer WHERE user_id = NEW.user_id);
    -- 更新归一化后的数据
    UPDATE movie_usertagpreferencedegree
    SET preference_score = (NEW.score - @mean) / @std_dev,
        last_updated = NOW(6)
    WHERE tag_id = NEW.tag_id AND user_id = NEW.user_id;
END;

